document.addEventListener('DOMContentLoaded', async () => {
  // Log a message when the page loads
  console.log("Athlete profile page loaded!");

  // Highlight table rows on hover
  document.querySelectorAll("table tbody tr").forEach(row => {
    row.addEventListener("mouseover", () => {
      row.style.backgroundColor = "#f0f8ff";
    });

    row.addEventListener("mouseout", () => {
      row.style.backgroundColor = "transparent";
    });
  });

  // Get the userId from localStorage
  const userId = localStorage.getItem('userId');
  
  if (userId) {
    // Fetch user details using the GET API
    const response = await fetch(`http://localhost:8080/api/athlete/${userId}/details`);
    
    if (response.ok) {
      const data = await response.json();

      // Populate profile information with data from API or 'N/A' if not available
      const profileInfo = document.querySelector(".profile-info");
      profileInfo.querySelector('h2').textContent = data.name || 'N/A';
      profileInfo.querySelector('p:nth-child(2)').innerHTML = `<strong>Date of Birth:</strong> ${data.dob || 'N/A'}`;
      profileInfo.querySelector('p:nth-child(3)').innerHTML = `<strong>Gender:</strong> ${data.gender || 'N/A'}`;
      profileInfo.querySelector('p:nth-child(4)').innerHTML = `<strong>Height:</strong> ${data.height || 'N/A'}`;
      profileInfo.querySelector('p:nth-child(5)').innerHTML = `<strong>Weight:</strong> ${data.weight || 'N/A'}`;
      profileInfo.querySelector('p:nth-child(6)').innerHTML = `<strong>Category:</strong> ${data.category || 'N/A'}`;
      profileInfo.querySelector('p:nth-child(7)').innerHTML = `<strong>Coach:</strong> ${data.coach || 'N/A'}`;
    } else {
      // If API call fails, alert the user
      alert("Failed to load profile details");
    }
  } else {
    // If no userId is found in localStorage
    alert("No user logged in");
  }

  // Add "Update Profile" button
  const profileInfo = document.querySelector(".profile-info");

  const updateButton = document.createElement("button");
  updateButton.textContent = "Update Profile";
  updateButton.style.marginTop = "10px";
  updateButton.style.padding = "10px";
  updateButton.style.cursor = "pointer";
  profileInfo.appendChild(updateButton);

  // Modal structure for updating profile
  const modal = document.createElement("div");
  modal.id = "updateModal";
  modal.style.display = "none";
  modal.style.position = "fixed";
  modal.style.top = "50%";
  modal.style.left = "50%";
  modal.style.transform = "translate(-50%, -50%)";
  modal.style.backgroundColor = "white";
  modal.style.padding = "20px";
  modal.style.boxShadow = "0 4px 8px rgba(0, 0, 0, 0.2)";
  modal.style.zIndex = "1000";
  modal.innerHTML = `
    <h3>Update Profile</h3>
    <form id="updateForm">
      <label for="name">Name:</label>
      <input type="text" id="name" placeholder="Enter new name" required><br><br>
      <label for="dob">Date of Birth:</label>
      <input type="date" id="dob" required><br><br>
      <label for="gender">Gender:</label>
      <input type="text" id="gender" placeholder="Enter gender" required><br><br>
      <label for="height">Height (cm):</label>
      <input type="number" id="height" placeholder="Enter height" required><br><br>
      <label for="weight">Weight (kg):</label>
      <input type="number" id="weight" placeholder="Enter weight" required><br><br>
      <label for="category">Category:</label>
      <input type="text" id="category" placeholder="Enter category" required><br><br>
      <label for="coach">Coach:</label>
      <input type="text" id="coach" placeholder="Enter coach name"><br><br>
      <button type="submit">Save Changes</button>
      <button type="button" id="closeModal">Cancel</button>
    </form>
  `;

  // Append modal to body
  document.body.appendChild(modal);

  // Show modal when clicking "Update Profile"
  updateButton.addEventListener("click", () => {
    modal.style.display = "block";

    // Pre-fill the form with existing profile details (if available)
    document.getElementById("name").value = data.name || '';
    document.getElementById("dob").value = data.dob || '';
    document.getElementById("gender").value = data.gender || '';
    document.getElementById("height").value = data.height || '';
    document.getElementById("weight").value = data.weight || '';
    document.getElementById("category").value = data.category || '';
    document.getElementById("coach").value = data.coach || '';
  });

  // Close modal
  document.getElementById("closeModal").addEventListener("click", () => {
    modal.style.display = "none";
  });

  // Save updated details and send to the server
  document.getElementById("updateForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const updatedDetails = {
      name: document.getElementById("name").value,
      dob: document.getElementById("dob").value,
      gender: document.getElementById("gender").value,
      height: document.getElementById("height").value,
      weight: document.getElementById("weight").value,
      category: document.getElementById("category").value,
      coach: document.getElementById("coach").value,
    };

    // Send updated data via POST request
    const updateResponse = await fetch(`http://localhost:8080/api/athlete/${userId}/save`, {
      method: 'POST',
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updatedDetails),
    });

    if (updateResponse.ok) {
      alert("Profile updated successfully!");
      modal.style.display = "none";
    } else {
      alert("Failed to update profile");
    }
  });

  // Add sorting functionality to tables
  document.querySelectorAll("table thead th").forEach((header, index) => {
    header.style.cursor = "pointer";
    header.addEventListener("click", () => {
      const table = header.closest("table");
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      const isAscending = header.classList.toggle("ascending");

      rows.sort((rowA, rowB) => {
        const cellA = rowA.cells[index].textContent.trim();
        const cellB = rowB.cells[index].textContent.trim();

        // Handle numeric and text sorting
        return isAscending
          ? cellA.localeCompare(cellB, undefined, { numeric: true })
          : cellB.localeCompare(cellA, undefined, { numeric: true });
      });

      // Append sorted rows to the table body
      rows.forEach(row => table.querySelector("tbody").appendChild(row));
    });
  });
  const uploadButton = document.createElement("button");
  uploadButton.textContent = "Upload Image";
  uploadButton.style.marginTop = "10px";
  uploadButton.style.padding = "10px";
  uploadButton.style.cursor = "pointer";
  profileInfo.appendChild(uploadButton);

  // Modal for image upload
  const uploadModal = document.createElement("div");
  uploadModal.id = "uploadModal";
  uploadModal.style.display = "none";
  uploadModal.style.position = "fixed";
  uploadModal.style.top = "50%";
  uploadModal.style.left = "50%";
  uploadModal.style.transform = "translate(-50%, -50%)";
  uploadModal.style.backgroundColor = "white";
  uploadModal.style.padding = "20px";
  uploadModal.style.boxShadow = "0 4px 8px rgba(0, 0, 0, 0.2)";
  uploadModal.style.zIndex = "1000";
  uploadModal.innerHTML = `
    <h3>Upload Profile Picture</h3>
    <form id="uploadForm">
      <label for="imageUpload">Choose an image:</label>
      <input type="file" id="imageUpload" required><br><br>
      <button type="submit">Upload</button>
      <button type="button" id="closeUploadModal">Cancel</button>
    </form>
  `;

  // Append modal to body
  document.body.appendChild(uploadModal);

  // Show upload modal on button click
  uploadButton.addEventListener("click", () => {
    uploadModal.style.display = "block";
  });

  // Close upload modal
  document.getElementById("closeUploadModal").addEventListener("click", () => {
    uploadModal.style.display = "none";
  });

  // Handle image upload
  document.getElementById("uploadForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const fileInput = document.getElementById("imageUpload");
    const formData = new FormData();
    formData.append("file", fileInput.files[0]);

    const uploadResponse = await fetch(`http://localhost:8080/api/athletes/${userId}/upload`, {
      method: 'POST',
      body: formData,
    });

    if (uploadResponse.ok) {
      alert("Image uploaded successfully!");
      uploadModal.style.display = "none";
      // Optionally, refresh the image by calling the GET API
      const imageResponse = await fetch(`http://localhost:8080/api/athletes/${userId}/image`);
      const imageData = await imageResponse.json();
      const profileImage = document.querySelector(".profile-info img");

      if (profileImage) {
        profileImage.src = `data:image/jpeg;base64,${imageData.imageBase64}`;
      }
    } else {
      alert("Failed to upload image");
    }
  });
});

package com.auth.Authentication.entity;

public enum EventStatus {
    UPCOMING,
    ONGOING,
    COMPLETED
}

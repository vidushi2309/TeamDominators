package com.auth.Authentication.Services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.auth.Authentication.Repository.EventRepository;
import com.auth.Authentication.dto.EventDTO;
import com.auth.Authentication.entity.Event;
import com.auth.Authentication.entity.EventStatus;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event createEvent(EventDTO eventDTO) throws IOException {
        Event event = new Event();
        event.setTitle(eventDTO.getTitle());
        event.setDate(eventDTO.getDate());
        event.setMeet(eventDTO.getMeet());
        event.setVenue(eventDTO.getVenue());
        event.setCategory(eventDTO.getCategory());
        event.setDescription(eventDTO.getDescription());

        // Save photo and generate URL
        String photoUrl = savePhoto(eventDTO.getPhoto());
        event.setPhotoUrl(photoUrl);

        // Determine event status
        event.setEventStatus(determineEventStatus(eventDTO.getDate()));

        return eventRepository.save(event);
    }

    private String savePhoto(MultipartFile photo) throws IOException {
        // Assuming a local file system directory "uploads/"
        String fileName = UUID.randomUUID() + "-" + photo.getOriginalFilename();
        Path filePath = Paths.get("uploads/" + fileName);
        Files.copy(photo.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
        return "/uploads/" + fileName;
    }

    private EventStatus determineEventStatus(LocalDate eventDate) {
        LocalDate today = LocalDate.now();
        if (eventDate.isAfter(today)) {
            return EventStatus.UPCOMING;
        } else if (eventDate.isEqual(today)) {
            return EventStatus.ONGOING;
        } else {
            return EventStatus.COMPLETED;
        }
    }
}
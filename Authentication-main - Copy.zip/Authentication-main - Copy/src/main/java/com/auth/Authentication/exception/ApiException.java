package com.auth.Authentication.exception;

public class ApiException extends RuntimeException {
    public ApiException(String message) { super(message); }
}
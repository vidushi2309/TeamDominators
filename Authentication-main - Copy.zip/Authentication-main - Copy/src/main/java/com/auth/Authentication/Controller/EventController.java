package com.auth.Authentication.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/events")
public class EventController {

    @PostMapping
    public ResponseEntity<String> createEvent(@RequestParam("event-title") String eventTitle,
                                              @RequestParam("event-date") String eventDate,
                                              @RequestParam("meet") String meet,
                                              @RequestParam("venue") String venue,
                                              @RequestParam("category") String category,
                                              @RequestParam("description") String description,
                                              @RequestParam("photo") MultipartFile photo) {
        try {
            if (photo.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Photo is required");
            }

            // Save the photo to a specific directory
            String uploadDir = "uploads/";
            String filename = photo.getOriginalFilename();
            Path path = Paths.get(uploadDir + filename);
            Files.copy(photo.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

            // Now you can save event data along with the photo path in the database

            return ResponseEntity.status(HttpStatus.CREATED).body("Event created successfully");

        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving event photo: " + e.getMessage());
        }
    }
}
